
async function fetchBalance() {
  const userDoc = await db.collection("users").doc(auth.currentUser.uid).get();
  document.getElementById("balance").innerText = "Balance: ₹" + (userDoc.data().balance || 0);
}

async function fetchTasks() {
  const tasksSnapshot = await db.collection("tasks").get();
  const taskList = document.getElementById("taskList");
  taskList.innerHTML = "";
  
  tasksSnapshot.forEach(doc => {
    const task = doc.data();
    const taskElement = document.createElement("div");
    taskElement.innerHTML = `
      <h3>${task.description}</h3>
      <p>Reward: ₹${task.reward}</p>
      <button onclick="completeTask('${doc.id}', ${task.reward})">Mark as Completed</button>
    `;
    taskList.appendChild(taskElement);
  });
}

async function completeTask(taskId, reward) {
  await db.collection("users").doc(auth.currentUser.uid).update({
    balance: firebase.firestore.FieldValue.increment(reward)
  });
  await db.collection("completedTasks").add({
    userId: auth.currentUser.uid,
    taskId: taskId,
    timestamp: firebase.firestore.Timestamp.now()
  });
  fetchBalance(); 
}

async function loginWithOTP() {
  const phoneNumber = prompt("Enter your phone number with country code:");
  const appVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
    'size': 'invisible',
    'callback': (response) => { loginWithOTP(); }
  });
  
  const confirmationResult = await auth.signInWithPhoneNumber(phoneNumber, appVerifier);
  const code = prompt("Enter the OTP sent to your phone:");
  confirmationResult.confirm(code)
    .then(() => {
      fetchBalance();
      fetchTasks();
    })
    .catch(error => console.error("Error signing in:", error));
}

auth.onAuthStateChanged(user => {
  if (user) {
    fetchBalance();
    fetchTasks();
  } else {
    loginWithOTP();
  }
});
